# Meetly.Api (backend)

ASP.NET Core Web API på .NET 10.

## Köra lokalt

```bash
cd backend/Meetly.Api
cp appsettings.Development.example.json appsettings.Development.json   # fyll i egna värden, committas inte
dotnet run
```

Testa: http://localhost:5080/api/health
OpenAPI (bara i Development): http://localhost:5080/openapi/v1.json

## Köra med Docker

```bash
docker build -t meetly-api ./backend
docker run --rm -p 8080:8080 meetly-api
```

Testa: http://localhost:8080/api/health

## Konfiguration

Sätts i `appsettings.Development.json` lokalt och som App Service-inställningar i Azure
(dubbla understreck ersätter kolon):

| Nyckel | Azure App Service-inställning | Används till |
|---|---|---|
| `ConnectionStrings:DefaultConnection` | `ConnectionStrings__DefaultConnection` | Azure SQL |
| `Jwt:Key` | `Jwt__Key` | JWT-signering |
| `Cors:AllowedOrigins` | `Cors__AllowedOrigins__0`, `__1` … | Frontend-URL:er |
| – | `WEBSITES_PORT` = `8080` | Containerns port |
