using Microsoft.AspNetCore.Mvc;

namespace Meetly.Api.Controllers;

/// <summary>
/// Enkel hälsokontroll. Används av frontend-skeletonet och för att
/// verifiera att containern är uppe efter en deploy.
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class HealthController : ControllerBase
{
    [HttpGet]
    public IActionResult Get() => Ok(new
    {
        status = "ok",
        service = "Meetly.Api",
        timeUtc = DateTime.UtcNow
    });
}
