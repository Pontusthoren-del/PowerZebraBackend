var builder = WebApplication.CreateBuilder(args);

// --- Services ---------------------------------------------------------------

builder.Services.AddControllers();
builder.Services.AddOpenApi();

// CORS: tillåtna frontend-URL:er läses från konfiguration.
// Lokalt: appsettings.Development.json
// Azure:  App Service-inställningar, t.ex. Cors__AllowedOrigins__0 = https://meetly.vercel.app
const string FrontendCorsPolicy = "Frontend";
var allowedOrigins = builder.Configuration
    .GetSection("Cors:AllowedOrigins")
    .Get<string[]>() ?? [];

builder.Services.AddCors(options =>
{
    options.AddPolicy(FrontendCorsPolicy, policy =>
        policy.WithOrigins(allowedOrigins)
              .AllowAnyHeader()
              .AllowAnyMethod());
});

// Här lägger vi senare till:
// - DbContext (EF Core + Azure SQL) – connection string: ConnectionStrings:DefaultConnection
// - JWT-autentisering (Viktor)    – nyckel: Jwt:Key

var app = builder.Build();

// --- Pipeline ---------------------------------------------------------------

if (app.Environment.IsDevelopment())
{
    // OpenAPI-dokumentet finns på /openapi/v1.json i utvecklingsläge
    app.MapOpenApi();
}

// Ingen UseHttpsRedirection: Azure App Service sköter HTTPS framför containern,
// och containern lyssnar bara på HTTP (port 8080).

app.UseCors(FrontendCorsPolicy);

// app.UseAuthentication();  // aktiveras när auth är på plats
app.UseAuthorization();

app.MapControllers();

app.Run();
